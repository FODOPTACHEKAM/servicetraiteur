import React from 'react';
import { motion } from 'framer-motion';
import {
  MessageSquare,
  Utensils,
  ShoppingBasket,
  Palette,
  PartyPopper,
  HeartHandshake } from
'lucide-react';
const steps = [
{
  icon: MessageSquare,
  title: 'Consultation & Planification',
  description:
  "Nous écoutons vos besoins et imaginons ensemble l'événement parfait.",
  image: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=800'
},
{
  icon: Utensils,
  title: 'Sélection du Menu',
  description:
  'Choix des mets parmi notre vaste répertoire de saveurs camerounaises et internationales.',
  image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800'
},
{
  icon: ShoppingBasket,
  title: 'Ingrédients Frais',
  description:
  'Achats au marché local le jour même pour garantir une fraîcheur absolue.',
  image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=800'
},
{
  icon: Palette,
  title: 'Mise en Place & Décoration',
  description:
  'Installation soignée et décoration des tables pour une ambiance féerique.',
  image: 'https://images.unsplash.com/photo-1478146059778-26028b07395a?w=800'
},
{
  icon: PartyPopper,
  title: 'Service & Animation',
  description: 'Un service impeccable et chaleureux pour ravir vos convives.',
  image: 'https://images.unsplash.com/photo-1530062845289-9109b2c9c868?w=800'
},
{
  icon: HeartHandshake,
  title: 'Satisfaction & Suivi',
  description:
  "Nous nous assurons que tout a été parfait jusqu'au dernier détail.",
  image: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800'
}];

export function ReceptionCycleSection() {
  return (
    <section className="py-24 bg-white overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-20">
          <h2 className="font-heading text-4xl md:text-5xl font-bold text-cameroon-green mb-4">
            Le Cycle d'une Réception Réussie
          </h2>
          <p className="text-gray-600 text-lg">
            Notre engagement qualité à chaque étape
          </p>
        </div>

        <div className="relative max-w-6xl mx-auto">
          {/* Vertical Line */}
          <motion.div
            initial={{
              height: 0
            }}
            whileInView={{
              height: '100%'
            }}
            viewport={{
              once: true
            }}
            transition={{
              duration: 1.5,
              ease: 'easeInOut'
            }}
            className="absolute left-4 md:left-1/2 top-0 w-1 bg-cameroon-gold/30 -translate-x-1/2 h-full rounded-full z-0" />


          <div className="space-y-16 md:space-y-24 relative z-10">
            {steps.map((step, index) =>
            <TimelineItem key={index} step={step} index={index} />
            )}
          </div>
        </div>
      </div>
    </section>);

}
function TimelineItem({ step, index }: {step: any;index: number;}) {
  const isEven = index % 2 === 0;
  const Icon = step.icon;
  return (
    <div
      className={`flex flex-col md:flex-row items-center gap-8 md:gap-16 ${isEven ? 'md:flex-row' : 'md:flex-row-reverse'}`}>

      {/* Image Side */}
      <motion.div
        initial={{
          opacity: 0,
          scale: 0.8,
          rotate: isEven ? -5 : 5
        }}
        whileInView={{
          opacity: 1,
          scale: 1,
          rotate: 0
        }}
        viewport={{
          once: true,
          margin: '-100px'
        }}
        transition={{
          duration: 0.6,
          delay: index * 0.1
        }}
        className="w-full md:w-1/2 flex justify-center md:justify-end">

        <div
          className={`relative w-full max-w-md aspect-[4/3] rounded-2xl overflow-hidden shadow-xl border-4 border-white ${isEven ? 'md:mr-8' : 'md:ml-8'}`}>

          <img
            src={step.image}
            alt={step.title}
            className="w-full h-full object-cover hover:scale-110 transition-transform duration-700" />

          <div className="absolute inset-0 bg-cameroon-green/10 hover:bg-transparent transition-colors duration-300" />
        </div>
      </motion.div>

      {/* Center Icon */}
      <div className="absolute left-4 md:left-1/2 -translate-x-1/2 flex items-center justify-center">
        <motion.div
          whileHover={{
            scale: 1.2,
            rotate: 360
          }}
          transition={{
            duration: 0.5
          }}
          className="w-12 h-12 md:w-16 md:h-16 bg-cameroon-green rounded-full border-4 border-cameroon-gold flex items-center justify-center z-10 shadow-lg">

          <Icon className="w-6 h-6 md:w-8 md:h-8 text-white" />
        </motion.div>
      </div>

      {/* Text Side */}
      <motion.div
        initial={{
          opacity: 0,
          x: isEven ? 50 : -50
        }}
        whileInView={{
          opacity: 1,
          x: 0
        }}
        viewport={{
          once: true,
          margin: '-100px'
        }}
        transition={{
          duration: 0.6,
          delay: index * 0.1 + 0.2
        }}
        className={`w-full md:w-1/2 pl-12 md:pl-0 ${isEven ? 'text-left md:pl-8' : 'text-left md:text-right md:pr-8'}`}>

        <h3 className="font-heading text-2xl md:text-3xl font-bold text-cameroon-green mb-3">
          {step.title}
        </h3>
        <p className="text-gray-600 text-lg leading-relaxed">
          {step.description}
        </p>
      </motion.div>
    </div>);

}