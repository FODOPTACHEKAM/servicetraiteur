import React from 'react';
import { motion } from 'framer-motion';
import {
  Users,
  Briefcase,
  Gift,
  Wine,
  Truck,
  GraduationCap } from
'lucide-react';
const services = [
{
  icon: Users,
  title: 'Mariages & Cérémonies',
  description:
  'Des menus sur mesure pour le plus beau jour de votre vie. Buffet ou service à table.',
  image: 'https://images.unsplash.com/photo-1519225421980-715cb0215aed?w=800'
},
{
  icon: Briefcase,
  title: "Événements d'Entreprise",
  description:
  "Cocktails, séminaires, repas d'affaires. Impressionnez vos partenaires.",
  image: 'https://images.unsplash.com/photo-1511578314322-379afb476865?w=800'
},
{
  icon: Gift,
  title: 'Anniversaires & Fêtes',
  description:
  'Célébrez vos moments joyeux avec des gâteaux spectaculaires et des buffets variés.',
  image: 'https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?w=800'
},
{
  icon: Wine,
  title: 'Buffets & Cocktails',
  description:
  'Une variété de bouchées fines et de boissons rafraîchissantes pour vos réceptions.',
  image: 'https://images.unsplash.com/photo-1529543544282-ea57407bc2e3?w=800'
},
{
  icon: Truck,
  title: 'Service à Domicile',
  description:
  'Le restaurant vient à vous. Profitez de nos chefs dans le confort de votre maison.',
  image: 'https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=800'
},
{
  icon: GraduationCap,
  title: 'Formation Culinaire',
  description:
  'Apprenez les secrets de la cuisine camerounaise avec nos ateliers pratiques.',
  image: 'https://images.unsplash.com/photo-1507048331197-7d4ac70811cf?w=800'
}];

export function ServicesSection() {
  return (
    <section
      id="services"
      className="py-24 bg-cameroon-cream bg-pattern-overlay">

      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="font-heading text-4xl md:text-6xl font-bold text-cameroon-green mb-4">
            Nos Services
          </h2>
          <div className="h-1 w-24 bg-cameroon-terracotta mx-auto"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) =>
          <ServiceCard key={index} service={service} index={index} />
          )}
        </div>

        {/* Closing Text */}
        <motion.div
          initial={{
            opacity: 0,
            y: 30
          }}
          whileInView={{
            opacity: 1,
            y: 0
          }}
          viewport={{
            once: true
          }}
          transition={{
            delay: 0.5
          }}
          className="mt-20 max-w-4xl mx-auto text-center">

          <div className="flex items-center justify-center gap-4 mb-8">
            <div className="h-px w-20 bg-cameroon-gold"></div>
            <span className="text-cameroon-gold text-2xl">✦</span>
            <div className="h-px w-20 bg-cameroon-gold"></div>
          </div>
          <p className="font-heading text-2xl md:text-3xl text-cameroon-green italic leading-relaxed">
            "Notre passion est de transformer chaque ingrédient local en une
            œuvre d'art culinaire, honorant ainsi la richesse du patrimoine
            gastronomique camerounais."
          </p>
        </motion.div>
      </div>
    </section>);

}
function ServiceCard({ service, index }: {service: any;index: number;}) {
  const Icon = service.icon;
  return (
    <motion.div
      initial={{
        opacity: 0,
        y: 50
      }}
      whileInView={{
        opacity: 1,
        y: 0
      }}
      viewport={{
        once: true
      }}
      transition={{
        duration: 0.6,
        delay: index * 0.1
      }}
      className="group relative h-[400px] rounded-xl overflow-hidden shadow-xl cursor-pointer">

      {/* Background Image with Zoom Effect */}
      <motion.div
        className="absolute inset-0 w-full h-full"
        whileHover={{
          scale: 1.1
        }}
        transition={{
          duration: 0.6
        }}>

        <img
          src={service.image}
          alt={service.title}
          className="w-full h-full object-cover" />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-cameroon-green via-cameroon-green/80 to-transparent opacity-90 group-hover:opacity-95 transition-opacity duration-300" />
      </motion.div>

      {/* Content */}
      <div className="absolute inset-0 p-8 flex flex-col justify-end text-white z-10">
        <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
          <div className="w-14 h-14 bg-cameroon-gold/20 backdrop-blur-sm rounded-full flex items-center justify-center mb-4 border border-cameroon-gold/50 group-hover:bg-cameroon-gold group-hover:text-cameroon-green transition-colors duration-300">
            <Icon className="w-7 h-7 text-cameroon-gold group-hover:text-cameroon-green transition-colors duration-300" />
          </div>

          <h3 className="font-heading text-2xl font-bold mb-3 text-cameroon-gold group-hover:text-white transition-colors">
            {service.title}
          </h3>

          <p className="text-gray-200 leading-relaxed opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300 delay-75">
            {service.description}
          </p>

          <div className="h-1 w-12 bg-cameroon-gold mt-4 transform scale-x-0 group-hover:scale-x-100 origin-left transition-transform duration-300 delay-150" />
        </div>
      </div>
    </motion.div>);

}