import React from 'react';
import { motion } from 'framer-motion';
import { Quote } from 'lucide-react';
export function AboutSection() {
  return (
    <section
      id="about"
      className="py-24 bg-cameroon-green text-white overflow-hidden">

      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center gap-12 md:gap-20">
          {/* Image Side */}
          <motion.div
            initial={{
              scale: 0.8,
              opacity: 0
            }}
            whileInView={{
              scale: 1,
              opacity: 1
            }}
            viewport={{
              once: true
            }}
            transition={{
              duration: 0.8
            }}
            className="w-full md:w-1/2 flex justify-center">

            <div className="relative w-64 h-64 md:w-96 md:h-96">
              <div className="absolute inset-0 border-4 border-cameroon-gold rounded-full animate-[spin_10s_linear_infinite]"></div>
              <div className="absolute inset-4 border-2 border-cameroon-terracotta rounded-full"></div>
              <img
                src="https://images.unsplash.com/photo-1583394293214-28ded15ee548?w=800&q=80"
                alt="Chef Cuisinier"
                className="absolute inset-6 w-[calc(100%-48px)] h-[calc(100%-48px)] object-cover rounded-full shadow-2xl" />

            </div>
          </motion.div>

          {/* Text Side */}
          <div className="w-full md:w-1/2 text-center md:text-left">
            <motion.h2
              initial={{
                x: 50,
                opacity: 0
              }}
              whileInView={{
                x: 0,
                opacity: 1
              }}
              viewport={{
                once: true
              }}
              className="font-heading text-4xl md:text-5xl font-bold mb-2">

              Le Chef
            </motion.h2>
            <motion.h3
              initial={{
                x: 50,
                opacity: 0
              }}
              whileInView={{
                x: 0,
                opacity: 1
              }}
              viewport={{
                once: true
              }}
              transition={{
                delay: 0.1
              }}
              className="text-cameroon-gold text-xl font-bold mb-6 uppercase tracking-widest">

              Derrière Saveurs du Cameroun
            </motion.h3>

            <motion.div
              initial={{
                x: 50,
                opacity: 0
              }}
              whileInView={{
                x: 0,
                opacity: 1
              }}
              viewport={{
                once: true
              }}
              transition={{
                delay: 0.2
              }}
              className="space-y-6 text-lg text-cameroon-cream/90 leading-relaxed">

              <p>
                Passionné par la richesse culinaire de notre terre, j'ai fondé
                Saveurs du Cameroun avec une mission simple : élever notre
                gastronomie au rang d'art.
              </p>
              <p>
                Chaque plat que nous servons raconte une histoire, celle de nos
                traditions, de nos épices et de notre hospitalité légendaire.
              </p>
            </motion.div>

            <motion.div
              initial={{
                opacity: 0
              }}
              whileInView={{
                opacity: 1
              }}
              viewport={{
                once: true
              }}
              transition={{
                delay: 0.5
              }}
              className="mt-8 p-6 bg-white/10 rounded-xl border-l-4 border-cameroon-gold relative">

              <Quote className="absolute top-4 left-4 w-8 h-8 text-cameroon-gold/30" />
              <p className="font-heading italic text-xl pl-8">
                "La cuisine est le seul art qui nourrit à la fois le corps et
                l'âme."
              </p>
              <p className="text-right mt-4 font-bold text-cameroon-gold">
                — Chef Jean-Pierre
              </p>
            </motion.div>
          </div>
        </div>
      </div>
    </section>);

}