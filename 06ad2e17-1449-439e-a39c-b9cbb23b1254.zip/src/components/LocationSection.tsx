import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, Clock, Phone } from 'lucide-react';
export function LocationSection() {
  return (
    <section
      id="location"
      className="py-20 bg-cameroon-cream relative overflow-hidden">

      <div className="container mx-auto px-4">
        <motion.div
          initial={{
            opacity: 0,
            x: -50
          }}
          whileInView={{
            opacity: 1,
            x: 0
          }}
          viewport={{
            once: true
          }}
          transition={{
            duration: 0.8
          }}
          className="flex flex-col md:flex-row gap-8 items-center">

          {/* Text Content */}
          <div className="w-full md:w-1/3 space-y-8">
            <div>
              <h2 className="font-heading text-4xl md:text-5xl font-bold text-cameroon-green mb-4">
                Notre Localisation
              </h2>
              <div className="h-1 w-20 bg-cameroon-gold mb-6"></div>
              <p className="text-gray-600 text-lg leading-relaxed">
                Situés au cœur de la capitale économique, nous desservons
                Douala, Yaoundé et les environs pour tous vos événements
                prestigieux.
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex items-start gap-4 p-4 bg-white rounded-lg shadow-md border-l-4 border-cameroon-gold">
                <div className="bg-cameroon-green/10 p-3 rounded-full">
                  <MapPin className="w-6 h-6 text-cameroon-green" />
                </div>
                <div>
                  <h3 className="font-bold text-cameroon-green text-lg">
                    Adresse
                  </h3>
                  <p className="text-gray-600">
                    123 Avenue de la Liberté
                    <br />
                    Akwa, Douala, Cameroun
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 bg-white rounded-lg shadow-md border-l-4 border-cameroon-gold">
                <div className="bg-cameroon-green/10 p-3 rounded-full">
                  <Clock className="w-6 h-6 text-cameroon-green" />
                </div>
                <div>
                  <h3 className="font-bold text-cameroon-green text-lg">
                    Horaires
                  </h3>
                  <p className="text-gray-600">
                    Lundi - Samedi: 08h00 - 18h00
                    <br />
                    Dimanche: Sur rendez-vous
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Map Placeholder */}
          <div className="w-full md:w-2/3 h-[400px] md:h-[500px] rounded-2xl overflow-hidden shadow-2xl relative group">
            <div className="absolute inset-0 bg-cameroon-green/20 z-10 pointer-events-none group-hover:bg-transparent transition-colors duration-500"></div>
            {/* Using an image as a map placeholder since we can't embed real Google Maps */}
            <img
              src="https://images.unsplash.com/photo-1569336415962-a4bd9f69cd83?w=1200&q=80"
              alt="Carte de localisation"
              className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 transform group-hover:scale-105" />

            <div className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none">
              <div className="bg-white/90 backdrop-blur-sm p-6 rounded-xl shadow-xl text-center">
                <MapPin className="w-10 h-10 text-cameroon-terracotta mx-auto mb-2 animate-bounce" />
                <p className="font-bold text-cameroon-green">Nous sommes ici</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>);

}