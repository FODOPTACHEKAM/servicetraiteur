import React, { Children } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
export function HeroSection() {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 500], [0, 200]);
  const opacity = useTransform(scrollY, [0, 300], [1, 0]);
  const containerVariants = {
    hidden: {
      opacity: 0
    },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3,
        delayChildren: 0.5
      }
    }
  };
  const itemVariants = {
    hidden: {
      y: 20,
      opacity: 0
    },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.8,
        ease: 'easeOut'
      }
    }
  };
  return (
    <section
      id="hero"
      className="relative h-screen w-full overflow-hidden flex items-center justify-center">

      {/* Background with Parallax */}
      <motion.div
        style={{
          y,
          opacity
        }}
        className="absolute inset-0 z-0">

        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-cameroon-green/90 z-10" />
        <img
          src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=1600&q=80"
          alt="Table de banquet élégante"
          className="w-full h-full object-cover" />

      </motion.div>

      {/* Content */}
      <motion.div
        className="relative z-10 text-center px-4 max-w-4xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate="visible">

        <motion.div variants={itemVariants} className="mb-4">
          <span className="inline-block py-1 px-3 border border-cameroon-gold text-cameroon-gold uppercase tracking-[0.2em] text-sm md:text-base bg-black/30 backdrop-blur-sm rounded-sm">
            Service Traiteur Premium
          </span>
        </motion.div>

        <motion.h1
          variants={itemVariants}
          className="font-heading text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-6 leading-tight text-shadow-lg">

          Saveurs du <span className="text-cameroon-gold">Cameroun</span>
        </motion.h1>

        <motion.p
          variants={itemVariants}
          className="text-xl md:text-2xl text-gray-200 mb-10 font-light max-w-2xl mx-auto text-shadow">

          L'Art de la Gastronomie Camerounaise sublimé pour vos moments
          d'exception.
        </motion.p>

        <motion.div variants={itemVariants}>
          <a
            href="#services"
            className="group inline-flex items-center gap-3 bg-cameroon-gold text-cameroon-green px-8 py-4 rounded-full font-bold text-lg hover:bg-white transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">

            Découvrir Nos Services
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </a>
        </motion.div>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.div
        className="absolute bottom-10 left-1/2 -translate-x-1/2 z-10 text-white flex flex-col items-center gap-2"
        initial={{
          opacity: 0
        }}
        animate={{
          opacity: 1
        }}
        transition={{
          delay: 2,
          duration: 1
        }}>

        <span className="text-xs uppercase tracking-widest text-white/70">
          Découvrir
        </span>
        <motion.div
          animate={{
            y: [0, 10, 0]
          }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: 'easeInOut'
          }}
          className="w-0.5 h-12 bg-gradient-to-b from-cameroon-gold to-transparent" />

      </motion.div>
    </section>);

}